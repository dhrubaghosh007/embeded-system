void dual_core(void);
