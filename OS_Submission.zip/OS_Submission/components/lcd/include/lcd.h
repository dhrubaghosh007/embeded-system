void lcd(void);
